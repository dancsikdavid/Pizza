﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Media.Imaging;

namespace piza
{
    public partial class MainWindow : Window
    {
        private List<Pizza> pizzas;
        private List<Ontet> ontetek;

        public MainWindow()
        {
            InitializeComponent();

            LoadPizzas();
            LoadOntetek();

            pizzaComboBox.ItemsSource = pizzas;
            pizzaComboBox.DisplayMemberPath = "Nev";

            ontetComboBox.ItemsSource = ontetek;
            ontetComboBox.DisplayMemberPath = "Nev";
        }

        private void LoadPizzas()
        {
            pizzas = File.ReadAllLines("pizzak.txt")
                         .Select(line => line.Split(';'))
                         .Select(parts => new Pizza(parts[0], double.Parse(parts[1])))
                         .ToList();
        }

        private void LoadOntetek()
        {
            ontetek = File.ReadAllLines("ontetek.txt")
                          .Select(line => line.Split(';'))
                          .Select(parts => new Ontet(parts[0], double.Parse(parts[1])))
                          .ToList();
        }

        private void rendelesButton_Click(object sender, RoutedEventArgs e)
        {

            if (pizzaComboBox.SelectedItem == null || ontetComboBox.SelectedItem == null ||
                string.IsNullOrEmpty(meretComboBox.Text) || string.IsNullOrEmpty(darabTextBox.Text))
            {
                MessageBox.Show("Kérlek, tölts ki minden mezőt!");
                return;
            }

            Pizza selectedPizza = (Pizza)pizzaComboBox.SelectedItem;
            Ontet selectedOntet = (Ontet)ontetComboBox.SelectedItem;
            string meret = meretComboBox.Text;
            int darab;
            if (!int.TryParse(darabTextBox.Text, out darab) || darab <= 0)
            {
                MessageBox.Show("Kérlek, adj meg egy érvényes darabszámot!");
                return;
            }

            double ar = (selectedPizza.Ar + selectedOntet.Ar) * darab;

            string rendeles = $"{selectedPizza.Nev};{meret};{darab};{selectedOntet.Nev};{ar}";
            File.AppendAllText("rendelesek.csv", rendeles + Environment.NewLine);

            MessageBox.Show("Rendelés sikeresen felvéve!");
        }
    }

    public class Pizza
    {
        public string Nev { get; }
        public double Ar { get; }

        public Pizza(string nev, double ar)
        {
            Nev = nev;
            Ar = ar;
        }

        public override string ToString()
        {
            return Nev;
        }
    }

    public class Ontet
    {
        public string Nev { get; }
        public double Ar { get; }

        public Ontet(string nev, double ar)
        {
            Nev = nev;
            Ar = ar;
        }

        public override string ToString()
        {
            return Nev;
        }
    }
}
